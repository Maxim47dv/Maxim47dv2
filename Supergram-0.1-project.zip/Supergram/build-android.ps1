$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$toolsDir = Join-Path $PSScriptRoot '.build-tools'
New-Item -ItemType Directory -Force $toolsDir | Out-Null
function Fetch-Zip($url, $name, $dest) {
    $zip = Join-Path $toolsDir $name
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip
    Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
}
if (!(Test-Path "$toolsDir\jdk")) {
    Fetch-Zip 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse' 'jdk.zip' "$toolsDir\jdk"
}
$jdkDir = Get-ChildItem "$toolsDir\jdk" -Directory | Select-Object -First 1
$env:JAVA_HOME = $jdkDir.FullName
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
if (!(Test-Path "$toolsDir\gradle-8.9\bin\gradle.bat")) {
    Fetch-Zip 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' 'gradle.zip' $toolsDir
}
$env:ANDROID_HOME = Join-Path $toolsDir 'sdk'
$sdkManager = Join-Path $env:ANDROID_HOME 'cmdline-tools\bin\sdkmanager.bat'
if (!(Test-Path $sdkManager)) {
    Fetch-Zip 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' 'android-tools.zip' $env:ANDROID_HOME
}
Write-Host 'Read the Android SDK licenses and accept them to continue.'
& $sdkManager "--sdk_root=$env:ANDROID_HOME" --licenses
if ($LASTEXITCODE -ne 0) { throw 'SDK license step failed' }
& $sdkManager "--sdk_root=$env:ANDROID_HOME" 'platforms;android-35' 'build-tools;34.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) { throw 'SDK installation failed' }
& "$toolsDir\gradle-8.9\bin\gradle.bat" :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'APK build failed' }
Write-Host "APK: $PSScriptRoot\app\build\outputs\apk\debug\app-debug.apk"
