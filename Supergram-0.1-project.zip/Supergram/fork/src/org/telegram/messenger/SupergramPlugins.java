package org.telegram.messenger;

import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Supergram v1 data plugins: no native code, network access, or background execution. */
public final class SupergramPlugins {
    private static SharedPreferences prefs(){return ApplicationLoader.applicationContext.getSharedPreferences("supergram_extra",0);}
    public static boolean option(String key){return prefs().getBoolean(key,false);}
    public static void option(String key,boolean value){prefs().edit().putBoolean(key,value).apply();}
    public static synchronized JSONArray list(){try{return new JSONArray(prefs().getString("plugins","[]"));}catch(Exception e){return new JSONArray();}}
    private static void save(JSONArray list){prefs().edit().putString("plugins",list.toString()).apply();}
    public static JSONObject parse(String raw)throws Exception {
        if(raw.length()>65536)throw new Exception("Файл больше 64 КБ");
        JSONObject p=new JSONObject(raw);
        if(p.optInt("schema")!=1||!p.optString("id").matches("[a-zA-Z0-9._-]{1,64}")||p.optString("name").trim().isEmpty())throw new Exception("Нужен плагин Supergram v1 (.sgplugin). Python-файлы exteraGram не поддерживаются.");
        JSONArray rules=p.optJSONArray("rules");if(rules==null||rules.length()>16)throw new Exception("Нужно от 0 до 16 правил");
        for(int i=0;i<rules.length();i++){JSONObject r=rules.getJSONObject(i);String t=r.getString("type");
            if(!t.equals("prefix")&&!t.equals("suffix")&&!t.equals("replace")&&!t.equals("command")&&!t.equals("trim")&&!t.equals("uppercase"))throw new Exception("Неизвестное правило: "+t);
            if((t.equals("replace")||t.equals("command"))&&r.optString("from").isEmpty())throw new Exception("Не заполнено поле from");
            if(r.optString("text").length()>4096||r.optString("from").length()>4096||r.optString("to").length()>4096)throw new Exception("Слишком длинное правило");
        }
        if(p.optString("name").length()>80||p.optString("description").length()>1000)throw new Exception("Слишком длинное описание");
        return p;
    }
    public static synchronized void install(JSONObject p)throws Exception {JSONArray all=list();JSONArray next=new JSONArray();for(int i=0;i<all.length();i++)if(!all.getJSONObject(i).getString("id").equals(p.getString("id")))next.put(all.get(i));if(next.length()>=24)throw new Exception("Максимум 24 плагина");p.put("enabled",false);next.put(p);save(next);}
    public static synchronized void toggle(String id,boolean on){JSONArray a=list();try{for(int i=0;i<a.length();i++)if(a.getJSONObject(i).getString("id").equals(id))a.getJSONObject(i).put("enabled",on);save(a);}catch(Exception ignored){}}
    public static synchronized void remove(String id){JSONArray a=list(),b=new JSONArray();try{for(int i=0;i<a.length();i++)if(!a.getJSONObject(i).getString("id").equals(id))b.put(a.get(i));save(b);}catch(Exception ignored){}}
    public static void seed(){if(prefs().getBoolean("seeded",false))return;try{
        install(parse("{\"schema\":1,\"id\":\"supergram.signature\",\"name\":\"Подпись Supergram\",\"version\":\"1.0\",\"description\":\"Добавляет подпись к исходящему тексту. Измените text в файле для своей подписи.\",\"rules\":[{\"type\":\"suffix\",\"text\":\"\\n— отправлено из Supergram\"}]}"));
        install(parse("{\"schema\":1,\"id\":\"supergram.commands\",\"name\":\"Быстрые ответы\",\"version\":\"1.0\",\"description\":\".hi → Привет!; .brb → Скоро вернусь.\",\"rules\":[{\"type\":\"command\",\"from\":\".hi\",\"to\":\"Привет!\"},{\"type\":\"command\",\"from\":\".brb\",\"to\":\"Скоро вернусь.\"}]}"));
        prefs().edit().putBoolean("seeded",true).apply();
    }catch(Exception ignored){}}
    public static String transform(String original){String text=original;if(text==null||text.isEmpty())return text;if(option("trim_text"))text=text.trim();
        if(!option("plugins_enabled"))return text;JSONArray all=list();for(int i=0;i<all.length();i++){try{JSONObject p=all.getJSONObject(i);if(!p.optBoolean("enabled"))continue;String candidate=apply(text,p.getJSONArray("rules"));if(candidate.isEmpty()||candidate.length()>4096)continue;text=candidate;}catch(Exception ignored){}}
        return text;
    }
    public static String apply(String original,JSONArray rules)throws Exception {String result=original;for(int i=0;i<rules.length();i++){JSONObject r=rules.getJSONObject(i);switch(r.getString("type")){case "trim":result=result.trim();break;case "uppercase":result=result.toUpperCase(java.util.Locale.ROOT);break;case "prefix":result=r.optString("text")+result;break;case "suffix":result+=r.optString("text");break;case "replace":result=result.replace(r.getString("from"),r.optString("to"));break;case "command":if(result.equals(r.getString("from")))result=r.optString("to");break;}if(result.length()>4096)throw new Exception("Результат слишком длинный");}return result;}
    public static String catalog(){return prefs().getString("catalog","https://t.me/exteraPlugins");}
    public static void catalog(String value){prefs().edit().putString("catalog",value).apply();}
    public static void pauseAll(){option("plugins_enabled",false);}
}
