package org.telegram.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.SupergramPlugins;
import org.telegram.messenger.browser.Browser;
import org.telegram.ui.ActionBar.ActionBar;
import org.telegram.ui.ActionBar.AlertDialog;
import org.telegram.ui.ActionBar.BaseFragment;
import org.telegram.ui.ActionBar.Theme;
import java.io.*;

public final class SupergramSettingsActivity extends BaseFragment {
    private LinearLayout list;
    private String exporting;
    private int dp(float v){return AndroidUtilities.dp(v);}
    private int color(int key){return Theme.getColor(key);}
    @Override public View createView(Context context){
        actionBar.setTitle("Supergram");
        actionBar.setBackButtonImage(org.telegram.messenger.R.drawable.ic_ab_back);
        actionBar.setActionBarMenuOnItemClick(new ActionBar.ActionBarMenuOnItemClick(){@Override public void onItemClick(int id){if(id==-1)finishFragment();}});
        ScrollView scroll=new ScrollView(context);scroll.setFillViewport(true);scroll.setBackgroundColor(color(Theme.key_windowBackgroundWhite));
        list=new LinearLayout(context);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(0,dp(8),0,dp(24));scroll.addView(list,new ScrollView.LayoutParams(-1,-2));fragmentView=scroll;render();return scroll;
    }
    private void section(String title){TextView text=new TextView(getContext());text.setText(title);text.setTextSize(14);text.setTypeface(Typeface.DEFAULT,Typeface.BOLD);text.setTextColor(color(Theme.key_windowBackgroundWhiteBlueText));text.setPadding(dp(20),dp(20),dp(20),dp(8));list.addView(text,new LinearLayout.LayoutParams(-1,-2));}
    private TextView paragraph(String title){TextView t=new TextView(getContext());t.setText(title);t.setTextSize(14);t.setTextColor(color(Theme.key_windowBackgroundWhiteGrayText));t.setPadding(dp(20),dp(8),dp(20),dp(12));list.addView(t,new LinearLayout.LayoutParams(-1,-2));return t;}
    private void row(String title,String subtitle,Runnable click){LinearLayout row=new LinearLayout(getContext());row.setOrientation(LinearLayout.VERTICAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setMinimumHeight(dp(64));row.setPadding(dp(20),dp(10),dp(20),dp(10));TextView a=new TextView(getContext());a.setText(title);a.setTextSize(16);a.setTextColor(color(Theme.key_windowBackgroundWhiteBlackText));row.addView(a);if(subtitle!=null&&!subtitle.isEmpty()){TextView b=new TextView(getContext());b.setText(subtitle);b.setTextSize(13);b.setTextColor(color(Theme.key_windowBackgroundWhiteGrayText));row.addView(b);}row.setBackground(Theme.getSelectorDrawable(false));row.setFocusable(true);row.setContentDescription(title);row.setOnClickListener(v->click.run());list.addView(row,new LinearLayout.LayoutParams(-1,-2));}
    private void toggle(String title,String detail,String key){LinearLayout row=new LinearLayout(getContext());row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(20),dp(8),dp(20),dp(8));row.setMinimumHeight(dp(72));LinearLayout labels=new LinearLayout(getContext());labels.setOrientation(1);TextView a=new TextView(getContext());a.setText(title);a.setTextSize(16);a.setTextColor(color(Theme.key_windowBackgroundWhiteBlackText));labels.addView(a);TextView b=new TextView(getContext());b.setText(detail);b.setTextSize(12);b.setTextColor(color(Theme.key_windowBackgroundWhiteGrayText));labels.addView(b);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(getContext());sw.setMinimumHeight(dp(48));sw.setContentDescription(title);sw.setChecked(SupergramPlugins.option(key));sw.setOnCheckedChangeListener((v,on)->SupergramPlugins.option(key,on));row.addView(sw);row.setBackground(Theme.getSelectorDrawable(false));row.setOnClickListener(v->sw.setChecked(!sw.isChecked()));list.addView(row);}
    private void render(){if(list==null)return;SupergramPlugins.seed();list.removeAllViews();
        section("Дополнительные настройки");
        toggle("Плагины","Применять включённые плагины к исходящему обычному тексту","plugins_enabled");
        toggle("Убирать лишние пробелы","Обрезать пробелы в начале и конце обычного текста","trim_text");
        toggle("Без предпросмотра ссылок","Не прикреплять превью веб-страниц к отправляемому тексту","no_link_preview");
        row("Оформление и фон Telegram","Штатные настройки чатов, темы и обои",()->presentFragment(new ThemeActivity(0)));
        section("Плагины");
        row("Каталог плагинов в Telegram",SupergramPlugins.catalog(),()->Browser.openUrl(getParentActivity(),SupergramPlugins.catalog()));
        row("Изменить ссылку на каталог","Указать свой публичный Telegram-канал",()->{EditText input=editor(SupergramPlugins.catalog());showDialog(new AlertDialog.Builder(getParentActivity()).setTitle("Telegram-каталог").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{String value=input.getText().toString().trim();if(!value.matches("https://t\\.me/[a-zA-Z0-9_]{5,64}/?")){info("Введите ссылку вида https://t.me/channel_name");return;}SupergramPlugins.catalog(value);render();}).create());});
        paragraph("Движок Supergram v1 использует файлы .sgplugin: правила обработки исходящего текста. Python-плагины .plugin/.py из exteraGram здесь не запускаются. Ссылка на @exteraPlugins ведёт во внешний каталог другого движка.");
        row("Установить из файла",".sgplugin • до 64 КБ • новые плагины выключены",()->{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");startActivityForResult(intent,19091);});
        row("Проверить плагины","Показать результат на примере без отправки сообщения",()->{EditText input=editor(".hi");showDialog(new AlertDialog.Builder(getParentActivity()).setTitle("Проверка без отправки").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Проверить",(d,w)->info(SupergramPlugins.transform(input.getText().toString()))).create());});
        JSONArray plugins=SupergramPlugins.list();for(int i=0;i<plugins.length();i++){JSONObject p=plugins.optJSONObject(i);if(p==null)continue;String id=p.optString("id");row(p.optString("name"),(p.optBoolean("enabled")?"Включён":"Выключен")+" • "+p.optString("version","1.0")+"\n"+p.optString("description"),()->showDialog(new AlertDialog.Builder(getParentActivity()).setTitle(p.optString("name")).setItems(new String[]{p.optBoolean("enabled")?"Выключить":"Включить","Экспортировать файл","Удалить"},(d,n)->{if(n==0){SupergramPlugins.toggle(id,!p.optBoolean("enabled"));render();}else if(n==1){exporting=p.toString();Intent export=new Intent(Intent.ACTION_CREATE_DOCUMENT);export.addCategory(Intent.CATEGORY_OPENABLE);export.setType("application/json");export.putExtra(Intent.EXTRA_TITLE,id+".sgplugin");startActivityForResult(export,19092);}else showDialog(new AlertDialog.Builder(getParentActivity()).setTitle("Удалить плагин?").setMessage(p.optString("name")).setNegativeButton("Отмена",null).setPositiveButton("Удалить",(a,b)->{SupergramPlugins.remove(id);render();}).create());}).create()));}
        row("Выключить все плагины","Быстро остановить обработку сообщений",()->{SupergramPlugins.pauseAll();render();});
        section("О Supergram");paragraph("Supergram 0.9.1 • основа Telegram для Android\nФормат плагинов: Supergram v1. Плагины работают с новыми текстовыми сообщениями без форматирования. Подписи к фото, видео и другим файлам не меняются.");
    }
    private EditText editor(String text){EditText input=new EditText(getContext());input.setTextColor(color(Theme.key_windowBackgroundWhiteBlackText));input.setHintTextColor(color(Theme.key_windowBackgroundWhiteGrayText));input.setPadding(dp(20),dp(12),dp(20),dp(12));input.setMinHeight(dp(48));input.setText(text);return input;}
    @Override public void onResume(){super.onResume();if(fragmentView!=null)fragmentView.setBackgroundColor(color(Theme.key_windowBackgroundWhite));render();}
    private void info(String text){showDialog(new AlertDialog.Builder(getParentActivity()).setTitle("Supergram").setMessage(text).setPositiveButton("Понятно",null).create());}
    @Override public void onActivityResultFragment(int requestCode,int resultCode,Intent data){super.onActivityResultFragment(requestCode,resultCode,data);if(resultCode!=Activity.RESULT_OK||data==null||data.getData()==null)return;try{
        if(requestCode==19092){if(exporting==null)return;try(OutputStream out=getParentActivity().getContentResolver().openOutputStream(data.getData())){if(out==null)throw new IOException("Нет доступа к файлу");out.write(exporting.getBytes(java.nio.charset.StandardCharsets.UTF_8));}exporting=null;info("Плагин сохранён.");return;}
        if(requestCode!=19091)return;String raw;try(InputStream in=getParentActivity().getContentResolver().openInputStream(data.getData());ByteArrayOutputStream buffer=new ByteArrayOutputStream()){if(in==null)throw new IOException("Нет доступа к файлу");byte[] part=new byte[4096];int n;while((n=in.read(part))!=-1){if(buffer.size()+n>65536)throw new IOException("Максимум 64 КБ");buffer.write(part,0,n);}raw=buffer.toString("UTF-8");}
        JSONObject plugin=SupergramPlugins.parse(raw);showDialog(new AlertDialog.Builder(getParentActivity()).setTitle("Установить плагин?").setMessage(plugin.optString("name")+"\n"+plugin.optString("description")+"\n\nПравил: "+plugin.getJSONArray("rules").length()+"\nПосле установки плагин будет выключен. Плагин с таким же ID будет заменён.").setNegativeButton("Отмена",null).setPositiveButton("Установить",(d,w)->{try{SupergramPlugins.install(plugin);render();}catch(Exception e){info(e.getMessage());}}).create());
    }catch(Exception e){info(e.getMessage()==null?"Не удалось прочитать файл":e.getMessage());}}
}
