from pathlib import Path
import shutil
import sys
root=Path(sys.argv[1]); base=Path(__file__).parent
vendor=base/'vendor/zastogram'
for part in ['java','python']:
    shutil.copytree(vendor/'TMessagesProj/src/main'/part,root/'TMessagesProj/src/main'/part,dirs_exist_ok=True)
java=root/'TMessagesProj/src/main/java'
nc=java/'org/telegram/messenger/NotificationCenter.java'
text=nc.read_text(); needle='private static int totalEvents = 1;'
assert needle in text
text=text.replace(needle,needle+'\n    public static final int pluginsDidLoad = totalEvents++;\n    public static final int pluginsUpdated = pluginsDidLoad;')
nc.write_text(text)
app=java/'org/telegram/messenger/ApplicationLoader.java'; text=app.read_text()
needle='NativeLoader.initNativeLibs(ApplicationLoader.applicationContext);'
assert needle in text
text=text.replace(needle,needle+'\n        org.telegram.plugins.PluginsController.getInstance().init(applicationContext);')
needle='applicationInited = true;'; assert needle in text
text=text.replace(needle,needle+'\n        AndroidUtilities.runOnUIThread(() -> org.telegram.plugins.PluginsController.getInstance().startEnabledPlugins(), 1500);')
app.write_text(text)
au=java/'org/telegram/messenger/AndroidUtilities.java'; text=au.read_text()
needle='public static boolean openForView(File f, String fileName, String mimeType, final Activity activity, Theme.ResourcesProvider resourcesProvider, boolean restrict) {'
assert needle in text
text=text.replace(needle,needle+'''
        if (f != null && f.exists() && fileName != null && (fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".plugin") || fileName.toLowerCase(java.util.Locale.ROOT).endsWith(".elyx"))) {
            return org.telegram.ui.Plugins.PluginsActivity.offerInstall(activity, f);
        }
        if (f != null && f.exists() && org.telegram.plugins.PluginsController.fileHandlersActive
                && org.telegram.plugins.PluginsController.getInstance().dispatchFileOpen(f, fileName, activity)) return true;
'''); au.write_text(text)
# Installing a file stores it; enabling it is a separate explicit action in its settings.
controller=java/'org/telegram/plugins/PluginsController.java'; text=controller.read_text()
text=text.replace('meta.enabled = true;', 'meta.enabled = false;')
text=text.replace('if (isCompatible(toLoad)) {', 'if (toLoad.enabled && isCompatible(toLoad)) {')
controller.write_text(text)
ui=java/'org/telegram/ui/Plugins/PluginsActivity.java'; text=ui.read_text()
text=text.replace('getParentActivity().startActivityForResult(', 'startActivityForResult(')
text=text.replace('» установлен', '» установлен. Включите его в настройках плагина')
ui.write_text(text)
rootBuild=root/'build.gradle'; text=rootBuild.read_text()
needle='dependencies {'; assert needle in text
text=text.replace(needle,needle+"\n        classpath 'com.chaquo.python:gradle:16.1.0'",1)
rootBuild.write_text(text)
library=root/'TMessagesProj/build.gradle'
with library.open('a') as f:
    f.write('''
apply plugin: 'com.chaquo.python'
dependencies {
    implementation 'top.canyie.pine:core:0.3.0'
    implementation 'top.canyie.pine:xposed:0.2.0'
    implementation 'com.linkedin.dexmaker:dexmaker:2.28.6'
}
chaquopy {
    defaultConfig {
        version "3.11"
        buildPython "python3.11"
        pyc { src false }
        pip {
            install "beautifulsoup4"
            install "soupsieve<3.0.2"
            install "packaging"
            install "requests"
            install "typing_extensions"
            install "pyfiglet"
            install "PyYAML"
            install "Pillow"
            install "lxml"
            install "debugpy"
        }
    }
}
''')
appGradle=root/'TMessagesProj_App/build.gradle'; appGradle.write_text(appGradle.read_text().replace('Supergram-0.9.1','Supergram-0.10'))
props=root/'gradle.properties'; text=props.read_text(); import re
text=re.sub(r'^APP_VERSION_CODE=(\d+)$',lambda m:'APP_VERSION_CODE='+str(int(m.group(1))+1),text,flags=re.M);props.write_text(text)
print('Supergram Python compatibility engine and Telegram integration applied')
