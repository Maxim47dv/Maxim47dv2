package org.telegram.messenger;
import org.junit.Test;
import static org.junit.Assert.*;
import org.json.JSONArray;
import org.json.JSONObject;
public class SupergramPluginsTest {
 private JSONObject rule(String type)throws Exception{return new JSONObject().put("type",type);}
 private JSONObject plugin(JSONArray rules)throws Exception{return new JSONObject().put("schema",1).put("id","test.valid").put("name","Test").put("rules",rules);}
 @Test public void commandAndSuffixChain()throws Exception{
  JSONArray rules=new JSONArray().put(rule("command").put("from",".hi").put("to","Привет!")).put(rule("suffix").put("text","\n— SG"));
  assertEquals("Привет!\n— SG",SupergramPlugins.apply(".hi",rules));
 }
 @Test public void commandDoesNotReplacePartOfMessage()throws Exception{assertEquals("say .hi",SupergramPlugins.apply("say .hi",new JSONArray().put(rule("command").put("from",".hi").put("to","Hi"))));}
 @Test public void replacementIsLiteral()throws Exception{assertEquals("a!",SupergramPlugins.apply("a.*",new JSONArray().put(rule("replace").put("from",".*").put("to","!"))));}
 @Test(expected=Exception.class) public void rejectsUnknownFormat()throws Exception{SupergramPlugins.parse(plugin(new JSONArray()).put("schema",2).toString());}
 @Test(expected=Exception.class) public void rejectsEmptyReplacementSearch()throws Exception{SupergramPlugins.parse(plugin(new JSONArray().put(rule("replace").put("from",""))).toString());}
 @Test(expected=Exception.class) public void rejectsOversizedOutput()throws Exception{String large=new String(new char[4096]).replace('\0','x');SupergramPlugins.apply(large,new JSONArray().put(rule("suffix").put("text","!")));}
 @Test(expected=Exception.class) public void rejectsExcessiveNesting()throws Exception{SupergramPlugins.parse("{\"schema\":1,\"id\":\"a\",\"name\":\"A\",\"rules\":[],\"extra\":[[[[[[[[[0]]]]]]]]]}");}
 @Test public void quotedBracesAreText()throws Exception{assertEquals("A",SupergramPlugins.parse(plugin(new JSONArray().put(rule("suffix").put("text","[[[{{{"))).put("name","A").toString()).getString("name"));}
 @Test(expected=Exception.class) public void rejectsOversizedVersion()throws Exception{SupergramPlugins.parse(plugin(new JSONArray()).put("version",new String(new char[100]).replace('\0','v')).toString());}
}
