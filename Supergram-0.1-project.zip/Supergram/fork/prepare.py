"""Apply Supergram branding to the pinned official Telegram source checkout.

Run only in CI. Credentials come from Actions Secrets and are never committed.
The upstream chat UI, backgrounds, themes and settings are kept intact.
"""
from pathlib import Path
import os, re, json, shutil, sys

root = Path(sys.argv[1]).resolve()
app_id = os.environ.get('SUPERGRAM_API_ID', '')
app_hash = os.environ.get('SUPERGRAM_API_HASH', '')
if not re.fullmatch(r'[1-9][0-9]*', app_id) or not re.fullmatch(r'[a-fA-F0-9]{32}', app_hash):
    raise SystemExit('Configure the Supergram application secrets before building')

variables = root / 'TMessagesProj/src/main/java/org/telegram/messenger/BuildVars.java'
text = variables.read_text()
text, count_id = re.subn(r'public static int APP_ID\s*=\s*\d+;', 'public static int APP_ID = '+app_id+';', text)
text, count_hash = re.subn(r'public static String APP_HASH\s*=\s*"[^"]*";', 'public static String APP_HASH = "'+app_hash+'";', text)
assert count_id == count_hash == 1, 'Upstream application credentials definition changed'
for name in ['DEBUG_VERSION', 'LOGS_ENABLED', 'DEBUG_PRIVATE_VERSION', 'CHECK_UPDATES', 'SUPPORTS_PASSKEYS', 'SUPPORTS_FPNV']:
    text = re.sub(r'(public static boolean '+name+r'\s*=\s*)[^;]+;', r'\g<1>false;', text)
for name in ['SAFETYNET_KEY', 'GOOGLE_AUTH_CLIENT_ID', 'HUAWEI_APP_ID']:
    text = re.sub(r'(public static String '+name+r'\s*=\s*)"[^"]*";', r'\g<1>"";', text)
variables.write_text(text)

properties = root / 'gradle.properties'
text = properties.read_text()
text = re.sub(r'^APP_PACKAGE=.*$', 'APP_PACKAGE=org.supergram.app', text, flags=re.M)
text = re.sub(r'^org.gradle.jvmargs=.*$', 'org.gradle.jvmargs=-Xmx6g -XX:MaxMetaspaceSize=1g -Dfile.encoding=UTF-8', text, flags=re.M)
text += '\norg.gradle.workers.max=2\norg.gradle.parallel=false\n'
properties.write_text(text)

app = root / 'TMessagesProj_App/build.gradle'
text = app.read_text().replace('applicationIdSuffix ".beta"', 'applicationIdSuffix ""')
# Keep the upstream version for protocol diagnostics; distinguish the distribution.
text = text.replace('versionName APP_VERSION_NAME', 'versionName APP_VERSION_NAME + "-Supergram-0.8"')
app.write_text(text)

# Build for the user's ARM64 Android phone, retaining all application functionality.
build = root / 'build.gradle'
with build.open('a') as out:
    out.write('''
subprojects { p ->
    afterEvaluate {
        if (p.plugins.hasPlugin('com.android.application') || p.plugins.hasPlugin('com.android.library')) {
            p.android.defaultConfig.ndk.abiFilters.clear()
            p.android.defaultConfig.ndk.abiFilters.add('arm64-v8a')
            p.android.productFlavors.all { f ->
                f.ndk.abiFilters.clear()
                f.ndk.abiFilters.add('arm64-v8a')
            }
        }
    }
}
''')

# The bundled upstream Firebase configuration is a placeholder, not a push setup.
# Match our package so resource generation succeeds; no upstream OAuth client is used.
for config in root.glob('**/google-services.json'):
    data = json.loads(config.read_text())
    if data.get('client'):
        client = data['client'][0]
        client['client_info']['android_client_info']['package_name'] = 'org.supergram.app'
        client['oauth_client'] = []
        data['client'] = [client]
        config.write_text(json.dumps(data))

for strings in root.glob('TMessagesProj*/src/**/res/values*/strings.xml'):
    text = strings.read_text()
    text = re.sub(r'(<string\s+name="AppName(?:Beta)?"[^>]*>)[^<]*(</string>)', r'\g<1>Supergram\2', text)
    strings.write_text(text)

icon = Path(__file__).resolve().parents[1] / 'app/src/main/res/drawable-nodpi/supergram_icon.png'
destination = root / 'TMessagesProj/src/main/res/drawable-nodpi/supergram_icon.png'
destination.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(icon, destination)
for manifest in (root / 'TMessagesProj/config').glob('**/AndroidManifest*.xml'):
    text = manifest.read_text()
    text = re.sub(r'android:(icon|roundIcon)="@mipmap/[^\"]+"', r'android:\1="@drawable/supergram_icon"', text)
    manifest.write_text(text)

cmake = root / 'TMessagesProj/jni/CMakeLists.txt'
text = cmake.read_text().replace('set(CMAKE_CXX_STANDARD 17)', '''set_property(GLOBAL PROPERTY JOB_POOLS compile_pool=2 link_pool=1)
set(CMAKE_JOB_POOL_COMPILE compile_pool)
set(CMAKE_JOB_POOL_LINK link_pool)
set(CMAKE_CXX_STANDARD 17)''')
cmake.write_text(text)
print('Prepared Supergram 0.8 on official Telegram: original chat UI, backgrounds and settings retained')

__import__("runpy").run_path(str(Path(__file__).with_name("features.py")),run_name="__main__")
