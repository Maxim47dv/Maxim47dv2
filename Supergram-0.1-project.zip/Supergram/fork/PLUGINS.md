# Supergram plugins v1

Native settings: gear beside Search in the main chat list. Install .sgplugin JSON files, inspect their names and descriptions, then enable the engine and the chosen plugin. New installs are always disabled.

Rules execute on new outgoing plain text before sending: trim, uppercase, prefix/suffix(text), replace(from,to), command(from,to). Command matches the complete message. No network, arbitrary code, or background execution. Formatted messages with entities, media captions, and retries are excluded.

Limits: 64 KiB per import, 24 plugins, 16 rules per plugin, 4096 characters per output. Rule order and plugin order are preserved.

External Telegram catalog: https://t.me/exteraPlugins. That catalog contains Python plugins for a different engine. Its .plugin/.py files are not compatible with Supergram v1. The catalog URL is editable. Bundled examples work in Supergram and are initially disabled.

Additional preferences: trim outgoing plain text; omit webpage previews; disable all plugins at once. Standard Telegram appearance and wallpaper settings remain available.
