# Supergram 0.10 Python plugin compatibility

Python .plugin and Elyx files use an embedded CPython 3.11 / Chaquopy runtime and Pine/Xposed hooks. The compatibility SDK exposes exteraGram BasePlugin 1.4.5.3 APIs. Each plugin's app and SDK constraints are checked. This is a compatibility implementation; every external plugin is not guaranteed to work.

Open Supergram settings (gear beside search), then Python plugins. Use + to import a downloaded .plugin, or open its document in a Telegram chat. A newly imported plugin is disabled; open its settings to enable it. Settings, errors, delete and lifecycle are implemented by the Python engine. Catalog: https://t.me/exteraPlugins.

Existing .sgplugin text rules remain separate. Their switch does not control Python plugins.

Source and GPL-2.0 provenance for the compatibility engine are in vendor/zastogram/PROVENANCE.txt and LICENSE. No unrelated ZaStoGram application or network features are included.

Host Python SDK tests cover the loader, imports by plugin id, structured settings, text formatting and requirements. Android compilation checks the Java API integration. Host tests do not verify ARM64 method hooks or third-party plugins on a physical phone.
