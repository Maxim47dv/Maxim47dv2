from pathlib import Path
import shutil,re
root=Path(__import__('sys').argv[1])
base=Path(__file__).resolve().parent
java=root/'TMessagesProj/src/main/java'
for relative in ['org/telegram/messenger/SupergramPlugins.java','org/telegram/ui/SupergramSettingsActivity.java']:
    target=java/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(base/'src'/relative,target)
dialogs=java/'org/telegram/ui/DialogsActivity.java'
text=dialogs.read_text()
needle='ssb.setSpan(new ImageSpan(logoDrawable), 0, ssb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);'
assert text.count(needle)==1,'Upstream header logo changed'
text=text.replace(needle,'// Supergram uses a text title instead of the Telegram wordmark image.')
text=text.replace('new SpannableStringBuilder(getString(R.string.AppName))','new SpannableStringBuilder("Supergram")')
needle='ActionBarMenu menu = actionBar.createMenu();'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n        if (!onlySelect && folderId == 0 && communityId == 0) menu.addItem(190909, R.drawable.outline_profile_settings).setContentDescription("Supergram: плагины и дополнительные настройки");')
needle='public void onItemClick(int id) {'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n                if (id == 190909) { presentFragment(new SupergramSettingsActivity()); return; }')
dialogs.write_text(text)
sender=java/'org/telegram/messenger/SendMessagesHelper.java'
text=sender.read_text()
needle='public void sendMessage(SendMessageParams sendMessageParams) {'
assert text.count(needle)==1
text=text.replace(needle,needle+'''
        // Only plain new outgoing text is transformed; media and entity offsets stay intact.
        if (sendMessageParams.retryMessageObject == null && sendMessageParams.message != null
                && sendMessageParams.photo == null && sendMessageParams.document == null
                && (sendMessageParams.entities == null || sendMessageParams.entities.isEmpty())) {
            sendMessageParams.message = SupergramPlugins.transform(sendMessageParams.message);
        }
        if (SupergramPlugins.option("no_link_preview") && sendMessageParams.message != null) {
            sendMessageParams.searchLinks = false;
            sendMessageParams.webPage = null;
            sendMessageParams.mediaWebPage = null;
        }
''')
sender.write_text(text)
app=root/'TMessagesProj_App/build.gradle'
app.write_text(app.read_text().replace('Supergram-0.8','Supergram-0.9.1'))
properties=root/'gradle.properties'
text=properties.read_text()
text=re.sub(r'^APP_VERSION_CODE=(\d+)$',lambda m:'APP_VERSION_CODE='+str(int(m.group(1))+2),text,flags=re.M)
properties.write_text(text)
library=root/'TMessagesProj/build.gradle'
with library.open('a') as f:
    f.write("\ndependencies { testImplementation 'junit:junit:4.13.2'; testImplementation 'org.json:json:20240303' }\n")
target=root/'TMessagesProj/src/test/java/org/telegram/messenger/SupergramPluginsTest.java'
target.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(base/'SupergramPluginsTest.java',target)
print('Supergram 0.9: plugin manager, send hooks, extra preferences, text header applied')

# Brand the phone-entry screen with the same artwork as the launcher.
login=java/'org/telegram/ui/LoginActivity.java'
text=login.read_text()
needle='''        public PhoneView(Context context) {
            super(context);

            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);'''
assert text.count(needle)==1, 'PhoneView constructor changed'
text=text.replace(needle,needle+'''

            if (activityMode != MODE_CHANGE_PHONE_NUMBER) {
                ImageView supergramLogo = new ImageView(context);
                supergramLogo.setImageResource(R.drawable.supergram_icon);
                supergramLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                supergramLogo.setContentDescription("Supergram");
                android.graphics.drawable.GradientDrawable logoBackground = new android.graphics.drawable.GradientDrawable();
                logoBackground.setColor(android.graphics.Color.BLACK);
                logoBackground.setCornerRadius(dp(18));
                supergramLogo.setBackground(logoBackground);
                supergramLogo.setClipToOutline(true);
                addView(supergramLogo, LayoutHelper.createLinear(64, 64, Gravity.CENTER_HORIZONTAL, 0, 0, 0, 16));
            }
''')
needle='titleView.setText(getString(activityMode == MODE_CHANGE_PHONE_NUMBER ? R.string.ChangePhoneNewNumber : R.string.YourNumber));'
assert text.count(needle)==1
text=text.replace(needle,'titleView.setText(activityMode == MODE_CHANGE_PHONE_NUMBER ? getString(R.string.ChangePhoneNewNumber) : "Supergram · " + getString(R.string.YourNumber));')
login.write_text(text)
print('Supergram phone-entry artwork applied')

__import__("runpy").run_path(str(Path(__file__).with_name("python_engine.py")), run_name="__main__")
