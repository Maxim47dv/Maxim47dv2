package org.supergram.app;

import android.app.*;
import android.animation.*;
import android.view.animation.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.text.*;
import org.json.*;
import java.util.*;

/** Native Telegram-style screens; no Telegram session is simulated. */
public class ModernActivity extends MainActivity {
    int background, foreground, muted, panel, highlight, divider;
    boolean night;
    String folder="Все чаты", search="";
    LinearLayout bar, folderStrip;
    Dialog drawerDialog;
    boolean firstFrame = true, backwards;
    boolean motion(){return prefs.getBoolean("animations",true) && ValueAnimator.areAnimatorsEnabled();}
    void animateRows(){
        if(!motion())return;
        for(int i=0;i<Math.min(body.getChildCount(),8);i++){
            View child=body.getChildAt(i);child.setAlpha(0);child.setTranslationY(d(8));
            child.animate().alpha(1).translationY(0).setStartDelay(i*18L).setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
        }
    }
    void animateMessage(View view){
        if(!motion())return;view.setAlpha(0);view.setTranslationY(d(16));view.setScaleX(.94f);view.setScaleY(.94f);
        view.animate().alpha(1).translationY(0).scaleX(1).scaleY(1).setDuration(240).setInterpolator(new DecelerateInterpolator(1.5f)).start();
    }
    void selectFolder(String selected){
        if(folder.equals(selected))return;folder=selected;
        String[] folders={"Все чаты","Личные","Группы","Каналы"};
        for(int i=0;i<folders.length;i++){
            LinearLayout tab=(LinearLayout)folderStrip.getChildAt(i);boolean active=folders[i].equals(selected);
            ((TextView)tab.getChildAt(0)).setTextColor(active?Color.WHITE:0xFFCEDCE8);
            tab.setSelected(active);View marker=tab.getChildAt(1);marker.animate().cancel();marker.setBackground(round(Color.WHITE,2));
            if(motion()){if(active){marker.setScaleX(.35f);marker.animate().alpha(1).scaleX(1).setDuration(190).start();}else marker.animate().alpha(0).scaleX(.35f).setDuration(130).start();}
            else {marker.setAlpha(active?1:0);marker.setScaleX(1);}
        }
        fillChatRows();
    }
    final String[][] examples={
        {"Избранное","Личные заметки и сохранённые сообщения","И","#65A0CF",""},
        {"Команда Supergram","Обновлённый интерфейс уже здесь","С","#9677C9","2"},
        {"Android • обсуждение","Максим: Теперь выглядит гораздо лучше","A","#69AE91","12"},
        {"Плагины Supergram","Первое расширение: подпись к сообщениям","П","#D5A064","1"},
        {"Дизайн и темы","Светлая или тёмная? Выбирай в настройках","Д","#C77E98",""}
    };
    int d(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    void colors(){night=prefs.getBoolean("night",false);background=Color.parseColor(night?"#17212B":"#FFFFFF");foreground=Color.parseColor(night?"#E8EDF3":"#202B36");muted=Color.parseColor(night?"#8797A7":"#84919C");panel=Color.parseColor(night?"#232E3C":"#527DA3");highlight=Color.parseColor(night?"#7EB0D9":"#528FC0");divider=Color.parseColor(night?"#26333F":"#EDF0F2");}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams size(int w,int h){return new LinearLayout.LayoutParams(w<0?w:d(w),h<0?h:d(h));}
    GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));return g;}
    TextView txt(String s,int n,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(n);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold){t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));t.setSingleLine(true);t.setEllipsize(TextUtils.TruncateAt.END);}return t;}
    @Override TextView text(String s,int n){TextView t=txt(s,n,foreground,false);t.setPadding(d(20),d(12),d(20),d(12));return t;}
    @Override Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(highlight);b.setTextSize(15);b.setBackground(round(background,8));b.setOnClickListener(v->action.run());return b;}
    void clickable(View v,Runnable action){
        v.setMinimumHeight(d(48));v.setFocusable(true);
        v.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(night?0x33A8CBE4:0x228090A0),v.getBackground(),null));
        if(motion()){
            StateListAnimator states=new StateListAnimator();
            AnimatorSet down=new AnimatorSet();down.playTogether(ObjectAnimator.ofFloat(v,"scaleX",.975f),ObjectAnimator.ofFloat(v,"scaleY",.975f));down.setDuration(90);
            AnimatorSet up=new AnimatorSet();up.playTogether(ObjectAnimator.ofFloat(v,"scaleX",1f),ObjectAnimator.ofFloat(v,"scaleY",1f));up.setDuration(150);
            states.addState(new int[]{android.R.attr.state_pressed,android.R.attr.state_enabled},down);states.addState(new int[]{},up);v.setStateListAnimator(states);
        }
        v.setOnClickListener(w->action.run());
    }
    View icon(String glyph,int color,Runnable action){
        Glyph g=new Glyph(glyph,color);g.setMinimumWidth(d(48));
        String description=glyph.equals("menu")?"Открыть меню":glyph.equals("back")?"Назад":glyph.equals("search")?"Поиск чатов":glyph.equals("compose")?"Новое сообщение":glyph.equals("send")?"Сохранить сообщение":glyph.equals("attach")?"Прикрепить файл":"Действия чата";
        g.setContentDescription(description);clickable(g,action);
        g.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName(Button.class.getName());}});
        return g;
    }
    void frame(String title,String subtitle,boolean back){
        colors();setTheme(night?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);root=col();root.setBackgroundColor(background);root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,i.getSystemWindowInsetTop(),0,i.getSystemWindowInsetBottom());return i;});getWindow().setStatusBarColor(panel);getWindow().setNavigationBarColor(background);getWindow().getDecorView().setSystemUiVisibility(night?0:View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);setContentView(root);root.requestApplyInsets();
        if(!firstFrame && motion()){root.setAlpha(.55f);root.setTranslationX(d(backwards?-14:18));root.animate().alpha(1).translationX(0).setDuration(210).setInterpolator(new DecelerateInterpolator()).start();}
        firstFrame=false;backwards=false;
        bar=row();bar.setBackgroundColor(panel);root.addView(bar,size(-1,56));bar.addView(icon(back?"back":"menu",Color.WHITE,()->{if(back){backwards=true;page="Чаты";render();}else drawer();}),size(56,56));LinearLayout titles=col();titles.addView(txt(title,20,Color.WHITE,true),size(-1,subtitle.isEmpty()?56:30));if(!subtitle.isEmpty())titles.addView(txt(subtitle,12,0xFFD1DEE9,false),size(-1,20));bar.addView(titles,new LinearLayout.LayoutParams(0,-1,1));
    }
    void scrollBody(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=col();scroll.addView(body);}
    @Override void home(){page="Чаты";render();}
    @Override void render(){
        if(page.equals("Чаты")){chats();return;}
        if(page.equals("Плагины")){pluginScreen();return;}
        if(page.equals("Тема")){appearance();return;}
        frame("Настройки","",true);scrollBody();section("Аккаунт");setting("profile","Подключить Telegram","Подключение ещё не реализовано",()->note("Это демоверсия интерфейса. Вход в Telegram и настоящие чаты будут доступны после интеграции Telegram-библиотеки."));section("Настройки приложения");setting("theme","Оформление",night?"Тёмная тема":"Светлая тема",()->{page="Тема";appearance();});setting("plugin","Плагины","Установка и управление расширениями",()->{page="Плагины";pluginScreen();});setting("saved","Данные и память","Записи хранятся на устройстве",()->note("Записи и плагины хранятся в приватной памяти приложения. Доступа к сети у этой сборки нет."));section("О приложении");setting("info","Supergram 0.5","Независимый Android-прототип",()->note("Интерфейс вдохновлён AyuGram для Android. Supergram не связан с авторами AyuGram или Telegram. Настоящие переписки и медиа пока не подключены."));
    }
    void chats(){
        frame("Supergram","",false);bar.addView(icon("search",Color.WHITE,()->{EditText e=new EditText(this);e.setSingleLine();e.setHint("Название чата");new AlertDialog.Builder(this).setTitle("Поиск").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Найти",(x,w)->{search=e.getText().toString().trim();chats();}).show();}),size(52,56));
        LinearLayout tabs=row();tabs.setBackgroundColor(panel);folderStrip=tabs;root.addView(tabs,size(-1,48));for(String f:new String[]{"Все чаты","Личные","Группы","Каналы"}){LinearLayout tab=col();TextView t=txt(f,14,folder.equals(f)?Color.WHITE:0xFFCEDCE8,true);t.setGravity(Gravity.CENTER);tab.addView(t,new LinearLayout.LayoutParams(-1,0,1));View under=new View(this);under.setBackground(round(folder.equals(f)?Color.WHITE:Color.TRANSPARENT,2));LinearLayout.LayoutParams u=size(-1,3);u.setMargins(d(12),0,d(12),0);tab.addView(under,u);tab.setSelected(folder.equals(f));tab.setContentDescription(f);clickable(tab,()->selectFolder(f));tabs.addView(tab,new LinearLayout.LayoutParams(0,-1,1));}
        TextView demo=txt("Демо • примеры чатов, аккаунт не подключён",11,muted,false);demo.setPadding(d(16),0,0,0);root.addView(demo,size(-1,28));FrameLayout content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));ScrollView sc=new ScrollView(this);content.addView(sc,new FrameLayout.LayoutParams(-1,-1));body=col();body.setPadding(0,0,0,d(90));sc.addView(body);
        fillChatRows();View compose=icon("compose",Color.WHITE,()->conversation(0));compose.setBackground(round(highlight,30));compose.setElevation(d(5));clickable(compose,()->conversation(0));compose.setContentDescription("Новое сообщение в локальном Избранном");FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(d(58),d(58),Gravity.BOTTOM|Gravity.END);fp.setMargins(0,0,d(18),d(18));content.addView(compose,fp);
    }
    void fillChatRows(){body.removeAllViews();
        if(!search.isEmpty()){TextView q=text("Поиск: "+search+"   ×",13);q.setOnClickListener(v->{search="";chats();});body.addView(q);}
        for(int n=0;n<examples.length;n++){final int at=n;String[] c=examples[n];boolean group=n==2||n==4, channel=n==1||n==3;if(folder.equals("Личные")&&n!=0||folder.equals("Группы")&&!group||folder.equals("Каналы")&&!channel)continue;if(!search.isEmpty()&&!c[0].toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT)))continue;
            LinearLayout item=row();clickable(item,()->conversation(at));body.addView(item,size(-1,78));TextView avatar=txt(c[2],25,Color.WHITE,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(round(Color.parseColor(c[3]),30));LinearLayout.LayoutParams av=size(56,56);av.setMargins(d(12),0,d(12),0);item.addView(avatar,av);
            LinearLayout detail=col();item.addView(detail,new LinearLayout.LayoutParams(0,-1,1));LinearLayout top=row();LinearLayout.LayoutParams tp=size(-1,29);tp.topMargin=d(10);detail.addView(top,tp);top.addView(txt(c[0],16,foreground,true),new LinearLayout.LayoutParams(0,-1,1));TextView time=txt(n==0?"":"12:4"+n,12,muted,false);time.setPadding(0,0,d(14),0);top.addView(time,size(-2,-1));LinearLayout low=row();detail.addView(low,size(-1,28));String preview=c[1];if(n==0){JSONArray m=readMessages(0);if(m.length()>0)preview=m.optString(m.length()-1);}TextView sub=txt(preview,14,muted,false);sub.setSingleLine(true);sub.setEllipsize(TextUtils.TruncateAt.END);low.addView(sub,new LinearLayout.LayoutParams(0,-1,1));if(!c[4].isEmpty()){TextView badge=txt(c[4],12,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(round(highlight,13));LinearLayout.LayoutParams bp=size(c[4].length()>1?28:23,23);bp.setMargins(d(8),0,d(14),0);low.addView(badge,bp);}else low.addView(new View(this),size(14,1));View sep=new View(this);sep.setBackgroundColor(divider);detail.addView(sep,size(-1,1));
        }
        if(body.getChildCount()==0)body.addView(text("Ничего не найдено",16));        animateRows();
    }
    void drawer(){if(drawerDialog!=null && drawerDialog.isShowing())return;final Dialog dialog=new Dialog(this);drawerDialog=dialog;dialog.setOnDismissListener(di->drawerDialog=null);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout menu=col();menu.setBackgroundColor(background);LinearLayout head=col();head.setPadding(d(24),d(28),d(24),d(20));head.setBackgroundColor(panel);TextView av=txt("S",30,Color.WHITE,true);av.setBackground(round(0xFF7AA8CD,32));av.setGravity(Gravity.CENTER);head.addView(av,size(64,64));TextView name=txt("Supergram",18,Color.WHITE,true);LinearLayout.LayoutParams np=size(-1,42);np.topMargin=d(12);head.addView(name,np);head.addView(txt("Аккаунт не подключён",13,0xFFD4E2ED,false),size(-1,22));menu.addView(head);menuItem(menu,"saved","Избранное",()->{dialog.dismiss();conversation(0);});menuItem(menu,"plugin","Плагины",()->{dialog.dismiss();page="Плагины";render();});menuItem(menu,"theme","Оформление",()->{dialog.dismiss();page="Тема";render();});menuItem(menu,"settings","Настройки",()->{dialog.dismiss();page="Настройки";render();});TextView version=txt("Supergram для Android\nВерсия 0.5 • демо",12,muted,false);version.setPadding(d(24),d(20),0,0);menu.addView(version,size(-1,78));dialog.setContentView(menu);Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setGravity(Gravity.START|Gravity.TOP);w.setWindowAnimations(motion()?org.supergram.app.R.style.DrawerMotion:0);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams wa=w.getAttributes();wa.dimAmount=.4f;w.setAttributes(wa);}dialog.show();if(w!=null)w.setLayout(d(300),-1);}
    void menuItem(LinearLayout list,String glyph,String name,Runnable action){LinearLayout r=row();r.setPadding(d(12),0,d(16),0);r.addView(new Glyph(glyph,muted),size(48,54));r.addView(txt(name,15,foreground,true));clickable(r,action);list.addView(r,size(-1,54));}
    void section(String s){TextView t=txt(s,14,highlight,true);t.setPadding(d(20),d(12),0,0);t.setBackgroundColor(night?0xFF101923:0xFFF0F2F5);body.addView(t,size(-1,48));}
    void setting(String glyph,String title,String detail,Runnable action){LinearLayout r=row();r.setPadding(d(8),0,d(14),0);r.addView(new Glyph(glyph,muted),size(52,64));LinearLayout copy=col();copy.addView(txt(title,16,foreground,false),size(-1,27));copy.addView(txt(detail,12,muted,false),size(-1,21));r.addView(copy,new LinearLayout.LayoutParams(0,-2,1));r.addView(new Glyph("next",muted),size(20,36));clickable(r,action);body.addView(r,size(-1,68));}
    void appearance(){frame("Оформление","",true);scrollBody();section("Цветовая тема");setting("sun","Светлая",night?"Белый фон и синяя панель":"Выбрана",()->{prefs.edit().putBoolean("night",false).apply();appearance();});setting("moon","Тёмная",night?"Выбрана":"Тёмно-синий фон и мягкие акценты",()->{prefs.edit().putBoolean("night",true).apply();appearance();});section("Движение");LinearLayout motionRow=row();motionRow.setPadding(d(20),0,d(20),0);motionRow.addView(txt("Анимации интерфейса",16,foreground,false),new LinearLayout.LayoutParams(0,-1,1));Switch motionSwitch=new Switch(this);motionSwitch.setContentDescription("Анимации интерфейса");motionSwitch.setMinimumHeight(d(48));motionSwitch.setMinimumWidth(d(48));motionSwitch.setChecked(prefs.getBoolean("animations",true));motionRow.addView(motionSwitch);clickable(motionRow,()->motionSwitch.setChecked(!motionSwitch.isChecked()));motionSwitch.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("animations",on).apply());body.addView(motionRow,size(-1,64));section("Предпросмотр сообщений");LinearLayout sample=col();sample.setPadding(d(14),d(20),d(14),d(20));sample.setBackgroundColor(night?0xFF0E1621:0xFFDCE5DE);body.addView(sample);bubble(sample,"Так выглядят сообщения",false,"12:40");bubble(sample,"Теперь гораздо лучше!",true,"12:41");}
    void pluginScreen(){frame("Плагины","",true);scrollBody();section("Расширения");setting("add","Установить из файла","JSON • формат Supergram v1",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,7);});try{JSONArray a=new JSONArray(prefs.getString("plugins","[]"));if(a.length()==0){section("Пока нет установленных плагинов");body.addView(text("Плагины v1 добавляют подпись к локальным сообщениям. Плагины других клиентов пока не поддерживаются.",14));}for(int n=0;n<a.length();n++){final int index=n;JSONObject p=a.getJSONObject(n);LinearLayout r=row();r.setPadding(d(20),d(10),d(20),d(10));LinearLayout copy=col();copy.addView(txt(p.getString("name"),16,foreground,true));copy.addView(txt("Подпись: "+p.getString("suffix"),13,muted,false));r.addView(copy,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setContentDescription("Включить "+p.getString("name"));sw.setChecked(p.optBoolean("enabled",true));sw.setOnCheckedChangeListener((b,on)->{try{a.getJSONObject(index).put("enabled",on);prefs.edit().putString("plugins",a.toString()).apply();}catch(JSONException e){note("Ошибка настроек плагина");}});sw.setMinimumWidth(d(48));sw.setMinimumHeight(d(48));r.addView(sw);clickable(r,()->sw.setChecked(!sw.isChecked()));body.addView(r,size(-1,74));setting("trash","Удалить плагин",p.getString("name"),()->new AlertDialog.Builder(this).setMessage("Удалить плагин?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(di,w)->{a.remove(index);prefs.edit().putString("plugins",a.toString()).apply();pluginScreen();}).show());}}catch(JSONException e){note("Ошибка данных плагинов");}}
    JSONArray readMessages(int index){try{return new JSONArray(prefs.getString(index==0?"messages":"demo_"+index,"[]"));}catch(JSONException e){return new JSONArray();}}
    @Override void chat(){conversation(0);}
    void conversation(int index){page="Переписка";frame(examples[index][0],index==0?"локально на этом устройстве":"демонстрационная переписка",true);bar.addView(icon("more",Color.WHITE,()->new AlertDialog.Builder(this).setItems(new String[]{"О переписке","Очистить локальные сообщения"},(di,which)->{if(which==0)note("Это демонстрация интерфейса. Сообщения хранятся только на этом устройстве и не отправляются в Telegram.");else new AlertDialog.Builder(this).setMessage("Удалить твои локальные записи?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(a,b)->{prefs.edit().remove(index==0?"messages":"demo_"+index).apply();conversation(index);}).show();}).show()),size(48,56));ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(night?0xFF0E1621:0xFFDCE5DE);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));LinearLayout messages=col();messages.setPadding(d(10),d(16),d(10),d(16));scroll.addView(messages);TextView date=txt("Демонстрация",12,Color.WHITE,false);date.setGravity(Gravity.CENTER);date.setBackground(round(night?0xFF344354:0xFF9CACAA,14));LinearLayout.LayoutParams dt=size(130,26);dt.gravity=Gravity.CENTER;dt.bottomMargin=d(18);messages.addView(date,dt);if(index>0){bubble(messages,"Привет! Это пример нового оформления Supergram.",false,"12:40");bubble(messages,"Привычные чаты, меню и аккуратные сообщения.",false,"12:41");bubble(messages,"А свои сообщения можно проверить здесь?",true,"12:42");bubble(messages,"Да. Они сохранятся локально. Подключения к Telegram пока нет.",false,"12:42");}JSONArray a=readMessages(index);if(index==0&&a.length()==0){TextView empty=txt("Избранное\n\nСохраняй свои заметки на устройстве.\nОни останутся после закрытия приложения.",15,muted,false);empty.setTag("empty-note");empty.setGravity(Gravity.CENTER);messages.addView(empty,size(-1,190));}for(int n=0;n<a.length();n++)bubble(messages,a.optString(n),true,"локально");LinearLayout composer=row();composer.setPadding(d(4),d(6),d(4),d(6));composer.setBackgroundColor(background);composer.setElevation(d(2));root.addView(composer,size(-1,-2));composer.addView(icon("attach",muted,()->note("Отправка файлов появится после подключения Telegram.")),size(48,48));EditText input=new EditText(this);input.setHint("Сообщение");input.setTextColor(foreground);input.setHintTextColor(muted);input.setTextSize(16);input.setBackground(round(night?0xFF253341:0xFFF0F3F5,22));input.setPadding(d(14),d(10),d(12),d(10));input.setMinHeight(d(48));input.setMaxLines(5);composer.addView(input,new LinearLayout.LayoutParams(0,-2,1));View send=icon("send",highlight,()->{String s=input.getText().toString().trim();if(s.isEmpty())return;try{JSONArray ps=new JSONArray(prefs.getString("plugins","[]"));for(int n=0;n<ps.length();n++){JSONObject p=ps.getJSONObject(n);if(p.optBoolean("enabled",true))s+=p.getString("suffix");}JSONArray m=readMessages(index);m.put(s);prefs.edit().putString(index==0?"messages":"demo_"+index,m.toString()).apply();input.setText("");View emptyNote=messages.findViewWithTag("empty-note");if(emptyNote!=null)messages.removeView(emptyNote);bubble(messages,s,true,new java.text.SimpleDateFormat("HH:mm",Locale.ROOT).format(new Date()));animateMessage(messages.getChildAt(messages.getChildCount()-1));scroll.post(()->scroll.smoothScrollTo(0,messages.getBottom()));}catch(JSONException e){note("Ошибка плагина");}});composer.addView(send,size(48,48));send.setEnabled(false);send.setAlpha(.4f);input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){boolean enabled=s.toString().trim().length()>0;send.setEnabled(enabled);if(motion())send.animate().alpha(enabled?1f:.4f).setDuration(120).start();else send.setAlpha(enabled?1f:.4f);}public void afterTextChanged(Editable e){}});scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    void bubble(LinearLayout list,String s,boolean own,String time){LinearLayout b=col();b.setPadding(d(12),d(8),d(10),d(5));b.setBackground(round(own?(night?0xFF2B5278:0xFFDDF1CB):(night?0xFF182533:Color.WHITE),14));TextView message=txt(s,16,foreground,false);message.setMaxWidth(Math.min(d(290),getResources().getDisplayMetrics().widthPixels-d(90)));message.setTextIsSelectable(true);b.addView(message);TextView stamp=txt(time+(own?"  ✓✓":""),10,own?(night?0xFF9AC9EB:0xFF6F9D5E):muted,false);stamp.setGravity(Gravity.END);b.addView(stamp,size(-1,17));LinearLayout.LayoutParams p=size(-2,-2);p.gravity=own?Gravity.END:Gravity.START;p.setMargins(own?d(32):0,0,own?0:d(32),d(7));list.addView(b,p);}
    void note(String message){new AlertDialog.Builder(this).setMessage(message).setPositiveButton("Понятно",null).show();}
    @Override public void onBackPressed(){if(page.equals("Чаты"))super.onBackPressed();else {backwards=true;home();}}
    class Glyph extends View{
        final String name;final int color;final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        Glyph(String n,int c){super(ModernActivity.this);name=n;color=c;}
        void lines(Canvas c,float... points){Path path=new Path();path.moveTo(points[0],points[1]);for(int i=2;i<points.length;i+=2)path.lineTo(points[i],points[i+1]);c.drawPath(path,p);}
        void line(Canvas c,float a,float b,float x,float y){c.drawLine(a,b,x,y,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();c.translate((getWidth()-d(24))/2f,(getHeight()-d(24))/2f);c.scale(d(24)/24f,d(24)/24f);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);switch(name){
        case "menu":line(c,3,6,21,6);line(c,3,12,21,12);line(c,3,18,21,18);break;
        case "back":lines(c,13,4,5,12,13,20);line(c,5,12,21,12);break;
        case "next":lines(c,9,7,14,12,9,17);break;
        case "search":c.drawCircle(10,10,6.5f,p);line(c,15,15,21,21);break;
        case "compose":lines(c,5,16,4,21,9,20,21,8,17,4,5,16);line(c,14,7,18,11);break;
        case "send":lines(c,3,4,22,12,3,20,6,12,3,4);line(c,6,12,16,12);break;
        case "saved":lines(c,6,3,18,3,18,21,12,17,6,21,6,3);break;
        case "plugin":c.drawRoundRect(4,4,20,20,4,4,p);line(c,9,1,9,4);line(c,15,20,15,23);line(c,1,9,4,9);line(c,20,15,23,15);break;
        case "profile":c.drawCircle(12,7,4,p);c.drawArc(4,12,20,25,180,180,false,p);break;
        case "theme":c.drawCircle(12,12,9,p);c.drawCircle(8,8,1,p);c.drawCircle(15,7,1,p);c.drawCircle(6,13,1,p);lines(c,19,14,13,14,13,21);break;
        case "sun":c.drawCircle(12,12,4,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10);}break;
        case "moon":c.drawArc(3,3,21,21,40,280,false,p);c.drawArc(9,0,24,16,70,200,false,p);break;
        case "more":p.setStyle(Paint.Style.FILL);for(int y=5;y<22;y+=7)c.drawCircle(12,y,1.5f,p);break;
        case "add":line(c,12,4,12,20);line(c,4,12,20,12);break;
        case "trash":lines(c,6,7,7,21,17,21,18,7);line(c,4,5,20,5);line(c,9,2,15,2);break;
        case "attach":lines(c,8,15,15,8,18,11,10,19);c.drawArc(3,8,14,22,45,220,false,p);c.drawArc(10,2,21,14,220,200,false,p);break;
        case "info":c.drawCircle(12,12,9,p);line(c,12,11,12,17);c.drawPoint(12,7,p);break;
        default:c.drawCircle(12,12,6,p);c.drawCircle(12,12,2,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,12+(float)Math.cos(a)*7,12+(float)Math.sin(a)*7,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10);}
        }c.restore();}
    }
}
