package org.supergram.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;

public class MainActivity extends Activity {
    LinearLayout root, body; SharedPreferences prefs; String page="Чаты";
    final int ink=Color.rgb(228,237,247), blue=Color.rgb(73,161,242);
    public void onCreate(Bundle state) { super.onCreate(state); prefs=getSharedPreferences("supergram",0); home(); }
    TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(ink); t.setPadding(18,14,18,14); return t; }
    Button button(String s, Runnable action) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v->action.run()); return b; }
    void home() {
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(12,36,12,24); root.setBackgroundColor(Color.rgb(15,24,36)); setContentView(root);
        root.addView(text("➤  Суперграм",28)); root.addView(text("ДЕМО • без подключения к Telegram",13));
        LinearLayout nav=new LinearLayout(this); root.addView(nav);
        for(String p:new String[]{"Чаты","Плагины","Настройки"}) nav.addView(button(p,()->{page=p; render();}),new LinearLayout.LayoutParams(0,58,1));
        ScrollView scroll=new ScrollView(this); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); body=new LinearLayout(this); body.setOrientation(1); scroll.addView(body); render();
    }
    void render() {
        body.removeAllViews();
        if(page.equals("Чаты")) {
            body.addView(text("Твои чаты появятся после подключения аккаунта",16));
            body.addView(button("✦  Локальный блокнот",()->chat()));
            body.addView(text("Здесь можно проверить интерфейс и плагины. Сообщения хранятся только на этом устройстве.",14));
        } else if(page.equals("Плагины")) {
            body.addView(text("Расширения Суперграма",24));
            body.addView(text("Формат v1: JSON-плагины добавляют подпись к сообщениям блокнота. Доступа к сети и аккаунту у них нет.",15));
            body.addView(button("Установить из JSON-файла",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,7);}));
            try { JSONArray a=new JSONArray(prefs.getString("plugins","[]")); for(int n=0;n<a.length();n++) { final int index=n; JSONObject p=a.getJSONObject(n); Switch sw=new Switch(this); sw.setText(p.getString("name")+" • "+p.getString("suffix")); sw.setTextColor(ink); sw.setChecked(p.optBoolean("enabled",true)); sw.setOnCheckedChangeListener((b,on)->{try {a.getJSONObject(index).put("enabled",on); prefs.edit().putString("plugins",a.toString()).apply();}catch(JSONException e){error();}}); body.addView(sw); body.addView(button("Удалить «"+p.getString("name")+"»",()->{a.remove(index);prefs.edit().putString("plugins",a.toString()).apply();render();})); } } catch(JSONException e){error();}
        } else {
            body.addView(text("Подключение Telegram",24));
            body.addView(text("В этой сборке Telegram ещё не подключён. Ввод номера и кода входа появится после интеграции TDLib. Одних ключей для текущей версии недостаточно.",16));
            body.addView(text("Сохранение медиа и работа с настоящими чатами ещё не реализованы. Совместимость с чужими плагинами не заявлена.",15));
            body.addView(button("Очистить локальный блокнот",()->new AlertDialog.Builder(this).setMessage("Удалить все записи блокнота?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->prefs.edit().remove("messages").apply()).show()));
            body.addView(text("Суперграм 0.1 • независимый прототип",13));
        }
    }
    void chat() {
        body.removeAllViews(); body.addView(button("← К списку чатов",()->render())); body.addView(text("Локальный блокнот",24));
        try { JSONArray a=new JSONArray(prefs.getString("messages","[]")); for(int n=0;n<a.length();n++)body.addView(text(a.getString(n),18)); }catch(JSONException e){error();}
        EditText input=new EditText(this); input.setTextColor(ink); input.setHintTextColor(Color.GRAY);input.setHint("Напиши сообщение…");body.addView(input);
        body.addView(button("Сохранить",()->{String s=input.getText().toString().trim(); if(s.isEmpty())return; try {JSONArray plugins=new JSONArray(prefs.getString("plugins","[]"));for(int n=0;n<plugins.length();n++){JSONObject p=plugins.getJSONObject(n);if(p.optBoolean("enabled",true))s+=p.getString("suffix");}JSONArray a=new JSONArray(prefs.getString("messages","[]"));a.put(s);prefs.edit().putString("messages",a.toString()).apply();chat();}catch(JSONException e){error();}}));
    }
    protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data); if(request!=7||result!=RESULT_OK||data==null)return;
        try(InputStream stream=getContentResolver().openInputStream(data.getData())) {
            if(stream==null)throw new IOException(); ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=stream.read(buf))!=-1){out.write(buf,0,n);if(out.size()>16384)throw new IOException();}
            JSONObject p=new JSONObject(out.toString("UTF-8"));String id=p.getString("id"),name=p.getString("name"),suffix=p.getString("suffix");
            if(p.getInt("schemaVersion")!=1||!id.matches("[a-z0-9_.]{1,64}")||name.length()>64||name.trim().isEmpty()||suffix.length()>100)throw new IOException();
            new AlertDialog.Builder(this).setTitle("Установить «"+name+"»?").setMessage("Добавляет к новым записям: "+suffix+"\nРазрешения: изменение текста локального блокнота.").setNegativeButton("Отмена",null).setPositiveButton("Установить",(d,w)->{try {JSONArray a=new JSONArray(prefs.getString("plugins","[]"));for(int j=0;j<a.length();j++)if(a.getJSONObject(j).getString("id").equals(id)){Toast.makeText(this,"Этот плагин уже установлен",0).show();return;}JSONObject clean=new JSONObject();clean.put("id",id);clean.put("name",name);clean.put("suffix",suffix);clean.put("enabled",true);a.put(clean);prefs.edit().putString("plugins",a.toString()).apply();page="Плагины";render();}catch(JSONException e){error();}}).show();
        }catch(Exception e){new AlertDialog.Builder(this).setMessage("Не удалось прочитать плагин. Нужен JSON формата Суперграм v1, до 16 КБ.").setPositiveButton("Понятно",null).show();}
    }
    void error(){Toast.makeText(this,"Ошибка локальных данных",Toast.LENGTH_SHORT).show();}
}
