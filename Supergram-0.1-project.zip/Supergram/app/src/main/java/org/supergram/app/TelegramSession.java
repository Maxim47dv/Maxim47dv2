package org.supergram.app;

import android.content.*;
import android.os.*;
import android.security.keystore.*;
import android.util.Base64;
import org.drinkless.tdlib.*;
import org.json.JSONObject;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import java.util.*;

/** One TDLib client per process; all cache mutations and listeners run on the main thread. */
final class TelegramSession {
    interface Listener {void changed(); void error(String text);}
    interface Result {void done(TdApi.Object value);}
    private static TelegramSession singleton;
    static synchronized TelegramSession get(Context context){if(singleton==null)singleton=new TelegramSession(context.getApplicationContext());return singleton;}
    final Context context; final Handler main=new Handler(Looper.getMainLooper());
    final Map<Long,TdApi.Chat> chats=new HashMap<>();
    final Map<Long,TreeMap<Long,TdApi.Message>> history=new HashMap<>();
    final Map<Long,Long> readRequested=new HashMap<>();
    Client client; Listener listener; String auth="credentials",connection="Подключение…";
    TdApi.AuthorizationState authState; boolean busy,loading,ended; long currentChat;
    private int apiId; private String apiHash; private byte[] dbKey;
    private TelegramSession(Context c){context=c;}
    boolean ready(){return auth.equals("AuthorizationStateReady");}
    void notifyUi(){if(listener!=null)listener.changed();}
    void fail(String s){busy=false;if(listener!=null)listener.error(s);notifyUi();}
    boolean configured(){return context.getSharedPreferences("telegram-vault",0).contains("data");}
    SecretKey key() throws Exception {KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);String alias="supergram-telegram-v1";if(!ks.containsAlias(alias)){KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");gen.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return gen.generateKey();}return (SecretKey)ks.getKey(alias,null);}
    void save(int id,String hash) throws Exception {byte[] random=dbKey;if(random==null){random=new byte[32];new SecureRandom().nextBytes(random);}JSONObject data=new JSONObject();data.put("api_id",id);data.put("api_hash",hash);data.put("db_key",Base64.encodeToString(random,Base64.NO_WRAP));Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());byte[] encrypted=cipher.doFinal(data.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));context.getSharedPreferences("telegram-vault",0).edit().putString("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)).putString("data",Base64.encodeToString(encrypted,Base64.NO_WRAP)).apply();}
    void restore() throws Exception {SharedPreferences p=context.getSharedPreferences("telegram-vault",0);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p.getString("iv",""),Base64.NO_WRAP)));JSONObject data=new JSONObject(new String(cipher.doFinal(Base64.decode(p.getString("data",""),Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8));apiId=data.getInt("api_id");apiHash=data.getString("api_hash");dbKey=Base64.decode(data.getString("db_key"),Base64.NO_WRAP);}
    void start(){if(client!=null)return;try{restore();System.loadLibrary("tdjni");Client.execute(new TdApi.SetLogVerbosityLevel(0));auth="starting";client=Client.create(value->main.post(()->update(value)),exception->main.post(()->fail("Ошибка библиотеки Telegram")),exception->main.post(()->fail("Ошибка обработки ответа Telegram")));notifyUi();}catch(Throwable e){auth="credentials";fail("Не удалось запустить Telegram-библиотеку. "+e.getClass().getSimpleName());}}
    void submitCredentials(int id,String hash){if(client!=null&&!auth.equals("credentials")){fail("Ключи уже загружены. Сначала завершите вход или перезапустите приложение.");return;}try{save(id,hash);if(client==null)start();else{restore();auth="AuthorizationStateWaitTdlibParameters";parameters();notifyUi();}}catch(Exception e){fail("Не удалось сохранить ключи в защищённом хранилище Android.");}}
    void send(TdApi.Function<?> request,Result result){if(client==null){fail("Telegram ещё не запущен");return;}client.send(request,value->main.post(()->{if(result!=null)result.done(value);else if(value instanceof TdApi.Error)fail(((TdApi.Error)value).message);}));}
    void authRequest(TdApi.Function<?> request){if(busy)return;busy=true;notifyUi();send(request,value->{busy=false;if(value instanceof TdApi.Error)fail(((TdApi.Error)value).message);else notifyUi();});}
    void submit(String value){switch(auth){case "AuthorizationStateWaitPhoneNumber":authRequest(new TdApi.SetAuthenticationPhoneNumber(value,null));break;case "AuthorizationStateWaitCode":authRequest(new TdApi.CheckAuthenticationCode(value));break;case "AuthorizationStateWaitPassword":authRequest(new TdApi.CheckAuthenticationPassword(value));break;case "AuthorizationStateWaitEmailAddress":authRequest(new TdApi.SetAuthenticationEmailAddress(value));break;case "AuthorizationStateWaitEmailCode":authRequest(new TdApi.CheckAuthenticationEmailCode(new TdApi.EmailAddressAuthenticationCode(value)));break;default:fail("На этом этапе ввод не требуется");}}
    void parameters(){TdApi.SetTdlibParameters p=new TdApi.SetTdlibParameters();p.databaseDirectory=context.getFilesDir()+"/telegram";p.filesDirectory=context.getFilesDir()+"/telegram/files";p.databaseEncryptionKey=dbKey;p.useFileDatabase=true;p.useChatInfoDatabase=true;p.useMessageDatabase=true;p.useSecretChats=false;p.apiId=apiId;p.apiHash=apiHash;p.systemLanguageCode=Locale.getDefault().getLanguage();p.deviceModel=Build.MANUFACTURER+" "+Build.MODEL;p.systemVersion=Build.VERSION.RELEASE;p.applicationVersion="Supergram 0.4";send(p,value->{if(value instanceof TdApi.Error){auth="credentials";fail(((TdApi.Error)value).message);}});}
    void update(TdApi.Object value){
        if(value instanceof TdApi.UpdateAuthorizationState){authState=((TdApi.UpdateAuthorizationState)value).authorizationState;auth=authState.getClass().getSimpleName();busy=false;if(auth.equals("AuthorizationStateWaitTdlibParameters"))parameters();if(ready()){loadMore();}if(auth.equals("AuthorizationStateClosed")){client=null;currentChat=0;chats.clear();history.clear();readRequested.clear();ended=false;loading=false;auth="credentials";}notifyUi();return;}
        if(value instanceof TdApi.UpdateConnectionState){connection=((TdApi.UpdateConnectionState)value).state.getClass().getSimpleName();notifyUi();return;}
        if(value instanceof TdApi.UpdateNewChat){TdApi.Chat chat=((TdApi.UpdateNewChat)value).chat;chats.put(chat.id,chat);}
        else if(value instanceof TdApi.UpdateChatTitle){TdApi.UpdateChatTitle u=(TdApi.UpdateChatTitle)value;TdApi.Chat c=chats.get(u.chatId);if(c!=null)c.title=u.title;}
        else if(value instanceof TdApi.UpdateChatLastMessage){TdApi.UpdateChatLastMessage u=(TdApi.UpdateChatLastMessage)value;TdApi.Chat c=chats.get(u.chatId);if(c!=null){c.lastMessage=u.lastMessage;c.positions=u.positions;}}
        else if(value instanceof TdApi.UpdateChatPosition){TdApi.UpdateChatPosition u=(TdApi.UpdateChatPosition)value;TdApi.Chat c=chats.get(u.chatId);if(c!=null){ArrayList<TdApi.ChatPosition> positions=new ArrayList<>();if(c.positions!=null)for(TdApi.ChatPosition p:c.positions)if(!p.list.getClass().equals(u.position.list.getClass()))positions.add(p);positions.add(u.position);c.positions=positions.toArray(new TdApi.ChatPosition[0]);}}
        else if(value instanceof TdApi.UpdateChatReadInbox){TdApi.UpdateChatReadInbox u=(TdApi.UpdateChatReadInbox)value;TdApi.Chat c=chats.get(u.chatId);if(c!=null){c.unreadCount=u.unreadCount;c.lastReadInboxMessageId=u.lastReadInboxMessageId;}}
        else if(value instanceof TdApi.UpdateChatReadOutbox){TdApi.UpdateChatReadOutbox u=(TdApi.UpdateChatReadOutbox)value;TdApi.Chat c=chats.get(u.chatId);if(c!=null)c.lastReadOutboxMessageId=u.lastReadOutboxMessageId;}
        else if(value instanceof TdApi.UpdateNewMessage){put(((TdApi.UpdateNewMessage)value).message);}
        else if(value instanceof TdApi.UpdateMessageSendSucceeded){TdApi.UpdateMessageSendSucceeded u=(TdApi.UpdateMessageSendSucceeded)value;TreeMap<Long,TdApi.Message> map=history.get(u.message.chatId);if(map!=null)map.remove(u.oldMessageId);put(u.message);}
        else if(value instanceof TdApi.UpdateMessageSendFailed){TdApi.UpdateMessageSendFailed u=(TdApi.UpdateMessageSendFailed)value;TreeMap<Long,TdApi.Message> map=history.get(u.message.chatId);if(map!=null)map.remove(u.oldMessageId);put(u.message);fail("Telegram не смог отправить сообщение.");}
        else if(value instanceof TdApi.UpdateMessageContent){TdApi.UpdateMessageContent u=(TdApi.UpdateMessageContent)value;TreeMap<Long,TdApi.Message> m=history.get(u.chatId);if(m!=null&&m.containsKey(u.messageId))m.get(u.messageId).content=u.newContent;}
        else if(value instanceof TdApi.UpdateDeleteMessages){TdApi.UpdateDeleteMessages u=(TdApi.UpdateDeleteMessages)value;TreeMap<Long,TdApi.Message> m=history.get(u.chatId);if(m!=null)for(long id:u.messageIds)m.remove(id);}
        else return;
        notifyUi();
    }
    long order(TdApi.Chat c){if(c.positions!=null)for(TdApi.ChatPosition p:c.positions)if(p.list instanceof TdApi.ChatListMain)return p.order;return 0;}
    List<TdApi.Chat> ordered(){ArrayList<TdApi.Chat> list=new ArrayList<>();for(TdApi.Chat c:chats.values())if(order(c)>0)list.add(c);list.sort((a,b)->{int n=Long.compare(order(b),order(a));return n!=0?n:Long.compare(b.id,a.id);});return list;}
    void loadMore(){if(loading||ended||!ready())return;loading=true;send(new TdApi.LoadChats(new TdApi.ChatListMain(),100),value->{loading=false;if(value instanceof TdApi.Error){TdApi.Error e=(TdApi.Error)value;if(e.code==404)ended=true;else fail(e.message);}notifyUi();});}
    void put(TdApi.Message m){history.computeIfAbsent(m.chatId,id->new TreeMap<>()).put(m.id,m);}
    void open(long id){if(currentChat!=0&&currentChat!=id)closeChat();currentChat=id;send(new TdApi.OpenChat(id),null);getHistory(id,false);}
    void closeChat(){if(currentChat!=0){send(new TdApi.CloseChat(currentChat),null);currentChat=0;}}
    void getHistory(long id,boolean older){TreeMap<Long,TdApi.Message> known=history.get(id);TdApi.GetChatHistory req=new TdApi.GetChatHistory();req.chatId=id;req.fromMessageId=older&&known!=null&&!known.isEmpty()?known.firstKey():0;req.limit=50;send(req,value->{if(value instanceof TdApi.Messages){for(TdApi.Message m:((TdApi.Messages)value).messages)put(m);notifyUi();}else if(value instanceof TdApi.Error)fail(((TdApi.Error)value).message);});}
    void markRead(long chatId,long messageId){if(readRequested.getOrDefault(chatId,0L)>=messageId)return;readRequested.put(chatId,messageId);TdApi.ViewMessages req=new TdApi.ViewMessages();req.chatId=chatId;req.messageIds=new long[]{messageId};req.forceRead=true;try{Object source=Class.forName("org.drinkless.tdlib.TdApi$MessageSourceChatHistory").getConstructor().newInstance();req.getClass().getField("source").set(req,source);}catch(Exception ignored){}send(req,value->{});}
    void sendText(long id,String text,Result result){TdApi.InputMessageText content=new TdApi.InputMessageText();content.text=new TdApi.FormattedText(text,null);TdApi.SendMessage req=new TdApi.SendMessage();req.chatId=id;req.inputMessageContent=content;send(req,value->{if(value instanceof TdApi.Message){put((TdApi.Message)value);notifyUi();}result.done(value);});}
    void logout(){authRequest(new TdApi.LogOut());}
    static String text(TdApi.Message m){if(m==null)return "";if(m.content instanceof TdApi.MessageText)return ((TdApi.MessageText)m.content).text.text;String type=m.content.getClass().getSimpleName();if(type.equals("MessagePhoto"))return "Фотография";if(type.equals("MessageVideo"))return "Видео";if(type.equals("MessageVoiceNote"))return "Голосовое сообщение";if(type.equals("MessageSticker"))return "Стикер";if(type.equals("MessageDocument"))return "Документ";if(type.equals("MessageAudio"))return "Аудиозапись";return "Сообщение";}
}
